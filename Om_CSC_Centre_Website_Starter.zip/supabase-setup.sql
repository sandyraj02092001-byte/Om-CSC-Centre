-- Om CSC Centre: run this script in Supabase Dashboard > SQL Editor.
-- Review policies before using this for real customer data.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'staff' check (role in ('admin','staff')),
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name_en text not null,
  name_hi text not null default '',
  description_en text not null default '',
  description_hi text not null default '',
  active boolean not null default true,
  sort_order int not null default 100,
  created_at timestamptz not null default now()
);

create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  phone text not null check (char_length(phone) between 8 and 20),
  service text not null check (char_length(service) between 1 and 120),
  visit_date date,
  message text check (message is null or char_length(message) <= 500),
  status text not null default 'new' check (status in ('new','in_progress','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 150),
  body text not null check (char_length(body) between 1 and 1500),
  public_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.enquiries enable row level security;
alter table public.notices enable row level security;

-- Remove prior policies of the same names before re-running this script.
drop policy if exists "admins can read own profile" on public.profiles;
drop policy if exists "admins manage services" on public.services;
drop policy if exists "public reads active services" on public.services;
drop policy if exists "public creates enquiries" on public.enquiries;
drop policy if exists "admins manage enquiries" on public.enquiries;
drop policy if exists "public reads published notices" on public.notices;
drop policy if exists "admins manage notices" on public.notices;

create policy "admins can read own profile"
on public.profiles for select to authenticated
using (id = (select auth.uid()));

-- Admin/staff check is based on the protected profiles table. Only an existing admin
-- should be able to add/change profile roles; the initial admin is bootstrapped below.
create policy "public reads active services"
on public.services for select to anon, authenticated using (active = true);

create policy "admins manage services"
on public.services for all to authenticated
using (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin'))
with check (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin'));

create policy "public creates enquiries"
on public.enquiries for insert to anon, authenticated with check (
  char_length(name) between 1 and 80
  and char_length(phone) between 8 and 20
  and char_length(service) between 1 and 120
  and (message is null or char_length(message) <= 500)
);

create policy "admins manage enquiries"
on public.enquiries for all to authenticated
using (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin'))
with check (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin'));

create policy "public reads published notices"
on public.notices for select to anon, authenticated using (published = true);

create policy "admins manage notices"
on public.notices for all to authenticated
using (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin'))
with check (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin'));

grant select on public.services to anon, authenticated;
grant insert on public.enquiries to anon, authenticated;
grant select, update, delete on public.enquiries to authenticated;
grant select on public.notices to anon, authenticated;
grant insert, update, delete on public.notices to authenticated;
grant select on public.profiles to authenticated;
grant insert, update, delete on public.services to authenticated;

insert into public.services (name_en,name_hi,description_en,description_hi,sort_order) values
('Online form assistance','ऑनलाइन फॉर्म सहायता','Help filling forms on the relevant official website.','संबंधित आधिकारिक वेबसाइट पर फॉर्म भरने में सहायता।',1),
('Print, scan & photocopy','प्रिंट, स्कैन और फोटोकॉपी','Document printing, scanning and photocopy support.','दस्तावेज़ प्रिंटिंग, स्कैनिंग और फोटोकॉपी।',2),
('Resume & typing','रिज्यूमे और टाइपिंग','Resume formatting, typing and document preparation.','रिज्यूमे फॉर्मेटिंग, टाइपिंग और दस्तावेज़ तैयार करना।',3),
('Exam form assistance','परीक्षा फॉर्म सहायता','Guidance for exam applications and official notices.','परीक्षा आवेदन और आधिकारिक सूचनाओं के लिए मार्गदर्शन।',4),
('Photo & PDF preparation','फोटो और PDF तैयार करना','Resize photos and prepare files to published requirements.','निर्धारित आवश्यकताओं के अनुसार फोटो और फाइल तैयार करना।',5),
('Digital service guidance','डिजिटल सेवा मार्गदर्शन','Help finding official portals and understanding application steps.','आधिकारिक पोर्टल खोजने और आवेदन प्रक्रिया समझने में सहायता।',6)
on conflict do nothing;

-- IMPORTANT: create your first admin account using Supabase Dashboard > Authentication > Users.
-- Then copy that user's UUID and run the following separately, replacing the UUID:
-- insert into public.profiles (id, role) values ('PASTE-AUTH-USER-UUID-HERE', 'admin');
-- Do not make public signup available unless you intentionally want anyone to register.
-- Only run the insert after creating the account. Do not share the account password.
