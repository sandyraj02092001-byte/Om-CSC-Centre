/* Om CSC Centre setup:
   1) Paste your Supabase project URL and PUBLISHABLE/anon key below.
   2) Replace CENTRE_PHONE with your real number in international format without +.
   Never put a Supabase service_role/secret key in this file.
*/
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE";
const CENTRE_PHONE = ""; // Example: 919876543210 (replace with your own verified number)
const CENTRE_ADDRESS = "Darbhanga, Bihar, India";

const isConfigured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && SUPABASE_PUBLISHABLE_KEY && !SUPABASE_PUBLISHABLE_KEY.includes("PASTE_");
const sb = isConfigured && window.supabase ? window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY) : null;
let language = "en";
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const copy = (en, hi) => language === "hi" ? hi : en;
const escapeHtml = (v="") => String(v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
$("#year").textContent = new Date().getFullYear();

$("#languageToggle").addEventListener("click", () => {
  language = language === "en" ? "hi" : "en";
  document.documentElement.lang = language;
  $$("[data-en][data-hi]").forEach(el => { el.textContent = el.dataset[language]; });
  $("#languageToggle").textContent = language === "en" ? "हिंदी" : "English";
  $("#serviceSearch").placeholder = copy("Search services…", "सेवाएँ खोजें…");
  $("#serviceSearch").setAttribute("aria-label", copy("Search services", "सेवाएँ खोजें"));
});
$("#serviceSearch").addEventListener("input", e => {
  const term = e.target.value.trim().toLowerCase();
  $$("#servicesGrid .service-card").forEach(card => card.hidden = !card.textContent.toLowerCase().includes(term));
});
const phoneDigits = CENTRE_PHONE.replace(/\D/g,"");
if (phoneDigits) {
  $("#callLink").href = "tel:+" + phoneDigits;
  $("#whatsappLink").href = "https://wa.me/" + phoneDigits + "?text=" + encodeURIComponent("Hello Om CSC Centre, I need help with a service.");
} else {
  $("#callLink").addEventListener("click", e => { e.preventDefault(); alert("Centre phone number has not been configured yet."); });
  $("#whatsappLink").addEventListener("click", e => { e.preventDefault(); alert("Centre WhatsApp number has not been configured yet."); });
}

function showMessage(selector, message, error=false) {
  const el = $(selector); el.textContent = message; el.style.color = error ? "#a12828" : "var(--green)";
}
async function loadPublicContent() {
  if (!sb) return;
  const {data: services, error: serviceError} = await sb.from("services").select("id,name_en,name_hi,description_en,description_hi,active").eq("active",true).order("sort_order");
  if (!serviceError && services && services.length) {
    $("#servicesGrid").innerHTML = services.map(s => `<article class="service-card"><span class="service-icon">✦</span><h3>${escapeHtml(language==="hi" ? s.name_hi : s.name_en)}</h3><p>${escapeHtml(language==="hi" ? s.description_hi : s.description_en)}</p></article>`).join("");
    // Reapply any current search filter
    $("#serviceSearch").dispatchEvent(new Event("input"));
  }
  const {data: notices, error: noticeError} = await sb.from("notices").select("id,title,body,public_url,created_at").eq("published",true).order("created_at",{ascending:false}).limit(10);
  if (!noticeError && notices) renderNotices(notices);
}
function renderNotices(notices) {
  $("#noticesList").innerHTML = notices.length ? notices.map(n => `<article class="notice"><span class="notice-date">${new Date(n.created_at).toLocaleDateString(language==="hi"?"hi-IN":"en-IN",{day:"2-digit",month:"short"})}</span><div><h3>${escapeHtml(n.title)}</h3><p>${escapeHtml(n.body)}</p>${n.public_url ? `<p><a href="${escapeHtml(n.public_url)}" target="_blank" rel="noopener">Open link ↗</a></p>` : ""}</div></article>`).join("") : `<p>${escapeHtml(copy("No new notices yet.", "अभी कोई नई सूचना नहीं है।"))}</p>`;
}
$("#requestForm").addEventListener("submit", async e => {
  e.preventDefault();
  const form = e.currentTarget, fd = new FormData(form);
  const payload = {name:String(fd.get("name")).trim(), phone:String(fd.get("phone")).trim(), service:String(fd.get("service")), visit_date:fd.get("visit_date") || null, message:String(fd.get("message")||"").trim() || null};
  if (!payload.name || !payload.phone || !payload.service) return showMessage("#formMessage",copy("Please complete the required fields.","कृपया आवश्यक जानकारी भरें।"),true);
  if (!sb) {
    const text = `Om CSC Centre service request\nName: ${payload.name}\nPhone: ${payload.phone}\nService: ${payload.service}\nPreferred date: ${payload.visit_date || "Not specified"}\nMessage: ${payload.message || "None"}`;
    if (phoneDigits) {
      window.open("https://wa.me/"+phoneDigits+"?text="+encodeURIComponent(text),"_blank","noopener");
      showMessage("#formMessage",copy("WhatsApp draft opened. Configure Supabase to save requests to the dashboard.","WhatsApp संदेश खुल गया है। डैशबोर्ड में अनुरोध सहेजने के लिए Supabase सेट करें।"));
    } else {
      showMessage("#formMessage",copy("Demo mode: configure Supabase and your centre phone number before launch. No request was saved.","डेमो मोड: प्रकाशित करने से पहले Supabase और फोन नंबर सेट करें। अनुरोध सहेजा नहीं गया।"),true);
    }
    return;
  }
  const button = form.querySelector("button[type=submit]"); button.disabled = true;
  const {error} = await sb.from("enquiries").insert(payload);
  button.disabled = false;
  if (error) return showMessage("#formMessage",copy("We could not save your request. Please call or WhatsApp the centre.","अनुरोध सहेजा नहीं जा सका। कृपया केंद्र को कॉल या WhatsApp करें।"),true);
  form.reset();
  showMessage("#formMessage",copy("Request received. Please keep your phone available for confirmation.","अनुरोध प्राप्त हुआ। पुष्टि के लिए अपना फोन उपलब्ध रखें।"));
});

$("#adminOpen").addEventListener("click", e => { e.preventDefault(); $("#admin").hidden=false; $("#admin").scrollIntoView({behavior:"smooth"}); });
$("#adminClose").addEventListener("click", () => { $("#admin").hidden=true; });
$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!sb) return showMessage("#loginMessage","Add your Supabase project URL and publishable key in app.js first.",true);
  const fd = new FormData(e.currentTarget);
  const {error} = await sb.auth.signInWithPassword({email:fd.get("email"),password:fd.get("password")});
  if (error) return showMessage("#loginMessage",error.message,true);
  await loadAdmin();
});
$("#logoutButton").addEventListener("click", async () => { if (sb) await sb.auth.signOut(); $("#adminPanel").hidden=true; $("#adminLoginArea").hidden=false; });
async function checkAdmin() {
  if (!sb) return;
  const {data:{session}} = await sb.auth.getSession();
  if (session) await loadAdmin();
}
async function loadAdmin() {
  const {data:{user}} = await sb.auth.getUser();
  if (!user) return;
  const {data:profile,error:profileError} = await sb.from("profiles").select("role").eq("id",user.id).maybeSingle();
  if (profileError || !profile || profile.role !== "admin") {
    await sb.auth.signOut();
    return showMessage("#loginMessage","This account is not authorised as a centre admin. Add its user ID to the profiles table using the SQL instructions.",true);
  }
  $("#adminLoginArea").hidden=true; $("#adminPanel").hidden=false; $("#adminWho").textContent="Signed in: "+user.email;
  await Promise.all([loadRequests(),loadAdminNotices()]);
}
async function loadRequests() {
  const host=$("#adminRequests"); host.textContent="Loading…";
  const {data,error}=await sb.from("enquiries").select("id,name,phone,service,visit_date,message,status,created_at").order("created_at",{ascending:false}).limit(100);
  if(error){host.textContent="Could not load requests: "+error.message;return;}
  if(!data.length){host.textContent="No requests yet.";return;}
  host.innerHTML=`<table class="admin-table"><thead><tr><th>Date</th><th>Customer</th><th>Request</th><th>Status</th><th>Update</th></tr></thead><tbody>${data.map(r=>`<tr><td>${new Date(r.created_at).toLocaleString()}</td><td>${escapeHtml(r.name)}<br>${escapeHtml(r.phone)}</td><td>${escapeHtml(r.service)}${r.visit_date?`<br>Visit: ${escapeHtml(r.visit_date)}`:""}${r.message?`<br>${escapeHtml(r.message)}`:""}</td><td>${escapeHtml(r.status)}</td><td><select data-request-id="${r.id}" aria-label="Update request status"><option ${r.status==="new"?"selected":""}>new</option><option ${r.status==="in_progress"?"selected":""} value="in_progress">in_progress</option><option ${r.status==="completed"?"selected":""}>completed</option><option ${r.status==="cancelled"?"selected":""}>cancelled</option></select></td></tr>`).join("")}</tbody></table>`;
  host.querySelectorAll("select[data-request-id]").forEach(sel=>sel.addEventListener("change",async()=>{sel.disabled=true;const {error}=await sb.from("enquiries").update({status:sel.value}).eq("id",sel.dataset.requestId);sel.disabled=false;if(error)alert("Status update failed: "+error.message);else await loadRequests();}));
}
$("#noticeForm").addEventListener("submit",async e=>{
  e.preventDefault(); const fd=new FormData(e.currentTarget);
  const payload={title:String(fd.get("title")).trim(),body:String(fd.get("body")).trim(),public_url:String(fd.get("url")||"").trim()||null,published:true};
  const {error}=await sb.from("notices").insert(payload);
  if(error)return showMessage("#noticeMessage",error.message,true);
  e.currentTarget.reset();showMessage("#noticeMessage","Notice published.");await Promise.all([loadAdminNotices(),loadPublicContent()]);
});
async function loadAdminNotices(){
  const host=$("#adminNotices");
  const {data,error}=await sb.from("notices").select("id,title,created_at,published").order("created_at",{ascending:false}).limit(50);
  if(error){host.textContent=error.message;return;}
  host.innerHTML=data.length?data.map(n=>`<div class="admin-notice"><div><strong>${escapeHtml(n.title)}</strong><br><small>${new Date(n.created_at).toLocaleString()} • ${n.published?"Published":"Hidden"}</small></div><button class="btn btn-light" data-delete-notice="${n.id}" type="button">Delete</button></div>`).join(""):"No notices yet.";
  host.querySelectorAll("[data-delete-notice]").forEach(btn=>btn.addEventListener("click",async()=>{if(!confirm("Delete this notice?"))return;const {error}=await sb.from("notices").delete().eq("id",btn.dataset.deleteNotice);if(error)alert(error.message);else{await loadAdminNotices();await loadPublicContent();}}));
}
loadPublicContent();
checkAdmin();
